import numpy as np
import logging
import sys

'''类的设计部分。我们设计了car、cross、road1三个类。'''
class car(object):
    def __init__(self,id,start,end,speed,plantime):
        self.id=id
        self.start=start
        self.end=end
        self.speed=speed
        self.plantime=plantime



class cross(object):
    def __init__(self,id,roadID1,roadID2,roadID3,roadID4):
        self.id=id
        self.roadID1=roadID1
        self.roadID2=roadID2
        self.roadID3=roadID3
        self.roadID4=roadID4


class road1(object):
    def __init__(self,id,length,constrain_speed,channel,start,end,isDuplex):
        self.id=id
        self.length=length
        self.constrain_speed=constrain_speed
        self.channel=channel
        self.start=start
        self.end=end
        self.isDuplex=isDuplex



'''本函数功能为获取文件的行数'''
def  ContractDict(dir):
    n = 0
    with open(dir, 'r') as f:
        for line in f:
            n+=1 # print (G.number_of_edges())
    return n-1




'''本函数是根据road。txt构成一个road的list'''
def  get_graph(dir):
    n = 0
    ContractG=[]
    with open(dir, 'r') as f:
        for line in f.readlines()[1:]:#去掉表头，从第二行开始，
            line1 = line.strip().split(",")#按“，”分割
            ContractG.append([int(line1[4]),int(line1[5]),int(line1[1]),int(line1[6].replace(')',''))])
    # print (len(ContractG))  #60条边。
    return  ContractG




def get_new_matrix_dict(road_list):
    matrix_dict={}
    for road in road_list:
        matrix_dict[str(road.end)+"_"+str(road.start)]=road.length*road.constrain_speed
        if road.isDuplex==1:
            matrix_dict[str(road.start)+"_"+str(road.end)]=road.length*road.constrain_speed
    return matrix_dict



'''本函数是根据cross.txt内容，以及road.txt内容作为参数。
输出：pointlist（不知道）
交通图的邻接矩阵、
edges_dict每个路口以及和其相连接的路口

'''


def get_cross_matrix(cross_path,road_path):
    #负责读取Cross的节点数量。
    n=ContractDict(cross_path)
    matrix=np.zeros([n,n],dtype=int)
    #数据格式为[[1, 2, 10], [2, 3, 10], [3, 4, 10], [4, 5, 10], [5, 6, 10], [1, 7, 10], [2, 8, 10], [3, 9, 10], [4, 10, 10], [5, 11, 10], [6, 12, 10], [7, 8, 10], [8, 9, 10], [9, 10, 10], [10, 11, 10], [11, 12, 10], [7, 13, 10], [8, 14, 10], [9, 15, 10], [10, 16, 10], [11, 17, 10], [12, 18, 10], [13, 14, 10], [14, 15, 10], [15, 16, 10], [16, 17, 10], [17, 18, 10], [13, 19, 10], [14, 20, 10], [15, 21, 10], [16, 22, 10], [17, 23, 10], [18, 24, 10], [19, 20, 10], [20, 21, 10], [21, 22, 10], [22, 23, 10], [23, 24, 10], [19, 25, 10], [20, 26, 10], [21, 27, 10], [22, 28, 10], [23, 29, 10], [24, 30, 10], [25, 26, 10], [26, 27, 10], [27, 28, 10], [28, 29, 10], [29, 30, 10], [25, 31, 10], [26, 32, 10], [27, 33, 10], [28, 34, 10], [29, 35, 10], [30, 36, 10], [31, 32, 10], [32, 33, 10], [33, 34, 10], [34, 35, 10], [35, 36, 10]]
    contracg_G=get_graph(road_path)
    point_list=[]
    edges_dict={}#  每个路口与其相连接的路口
    # edges_list_name_dict={ }  # 两个路口间的路径名字
    for i  in range(len(contracg_G)):
            # print(contracg_G[i])
            x=contracg_G[i][0]
            y=contracg_G[i][1]
            z=contracg_G[i][2]
            # print (x,y,z)
            if y in edges_dict:
                edges_dict[y].append(x)
            else:
                edges_dict[y]=[x]
            if contracg_G[i][3] == 1:  # 等于1，为双向，否则为单向。
                if  x in edges_dict:
                    edges_dict[x].append(y)
                else:
                    edges_dict[x] = [y]

            point_list.append(x)
            point_list.append(y)
    # print(edges_dict)
    return point_list,edges_dict






'''迪杰斯特拉算法，
输入：
     edges：所有边。
     matrix：邻接矩阵
     edges_dict : edges_dict每个路口以及和其相连接的路口形成字典，格式如下1: [2, 9]
     start：车辆开始的点
     end：车辆结束的点

'''
def Dijkstra(edges,matrix,edges_dict,start,end):
    # RG = G.reverse()
    dist = {}; previous = {}
    for v in edges:
        dist[v] = float('inf')
        previous[v] = 'none'
    dist[end] = 0
    u = end
    # print(dist)
    while u!=start:
        u = min(dist, key=dist.get)
        distu = dist[u]
        del dist[u]
        # print( edges_dict[u])
        for v in list(set(edges_dict[u])):
            if v in dist:
                alt = distu +matrix[str(u)+"_"+str(v)]
                if alt < dist[v]:
                    dist[v] = alt
                    previous[v] = u
    path=(start,)
    last= start
    while last != end:
        nxt = previous[last]
        path += (nxt,)
        last = nxt
    return path,alt





'''读取文件并形成对应文件list
输入为：dir，以及对应的类名。例如：（'car.txt',car)
输出为对象list
'''

def  get_list(dir,classname):
    car_list = []
    with open(dir) as c:
        line0 = c.readline()
        line = c.readline()
        while (line):
            car_single = classname(*eval(line))
            car_list.append(car_single)
            line = c.readline()
    return car_list




'''



'''
def  get_answer(dir):
    n = 0

    answerList=[]
    with open(dir, 'r') as f:
        for line in f.readlines()[1:]:#去掉表头，从第二行开始，
            line2=line.replace('(','').replace(')','')
            line1 = line2.strip().split(",")#按“，”分割
            answerList.append(list(map(int, line1)))

    return  answerList

'''
根据anserList以及crosslist集合形成count列表，生成形成堵车的车辆id。

'''
def  get_lock(anserlist,crosslist):
    all_path = []  # [5036, 5049, 5063, 5078] 形式如左， 获取所有车的路径。
    for answer in anserlist:
        path = []
        for k in range(2, len(answer)):
            path.append(answer[k])
        all_path.append(path)
    # print (all_path)

    all_path_dirction = []  # [[[5036, 5049], [5049, 5063], [5063, 5078]], [[5079, 5064], [5064, 5050], [5050, 5037], [5037, 5024], [5024, 5009]], [[5040, 5055], [5055, 5069], [5069, 5083],
    for path_temp in all_path:
        path = []
        for index in range(0, len(path_temp)):
            if index < len(path_temp) - 1:
                path.append([path_temp[index], path_temp[index + 1]])
        all_path_dirction.append(path)

    # 开始判断每两个路的转向。形成dirction的list
    # 中文direction,用0表示直行，1表示左，2表示右
    dirction_path = []
    for dirction in all_path_dirction:
        for one_dirticon in dirction:
            for cross_temp in crosslist:
                if [cross_temp[1], cross_temp[2]] == one_dirticon:
                    one_dirticon.append(1)
                if [cross_temp[2], cross_temp[1]] == one_dirticon:
                    one_dirticon.append(2)
                if [cross_temp[1], cross_temp[3]] == one_dirticon:
                    one_dirticon.append(0)
                if [cross_temp[3], cross_temp[1]] == one_dirticon:
                    one_dirticon.append(0)
                if [cross_temp[2], cross_temp[3]] == one_dirticon:
                    one_dirticon.append(1)
                if [cross_temp[3], cross_temp[2]] == one_dirticon:
                    one_dirticon.append(2)
                if [cross_temp[3], cross_temp[4]] == one_dirticon:
                    one_dirticon.append(1)
                if [cross_temp[4], cross_temp[3]] == one_dirticon:
                    one_dirticon.append(2)
                if [cross_temp[4], cross_temp[1]] == one_dirticon:
                    one_dirticon.append(1)
                if [cross_temp[3], cross_temp[4]] == one_dirticon:
                    one_dirticon.append(1)
                if [cross_temp[1], cross_temp[4]] == one_dirticon:
                    one_dirticon.append(2)
                if [cross_temp[2], cross_temp[4]] == one_dirticon:
                    one_dirticon.append(0)
                if [cross_temp[4], cross_temp[2]] == one_dirticon:
                    one_dirticon.append(0)
    # 拿到所有转向。
    all_dirctionlist = []  # [[0, 0, 0], [0, 0, 0, 0, 0], [0, 0, 0, 0],
    for i in all_path_dirction:
        diection_str = ''
        for j in i:
            diection_str = diection_str + str(j[2])
        all_dirctionlist.append(diection_str)
    # print (all_dirctionlist)

    # 开始做匹配工作。让我们来试试看行不行。首先看看最长的有多少。我们认为最少都得有3才行。
    # import re
    #
    # # print(list(enumerate(all_dirctionlist)))
    # pattern = re.compile(r'10{0,10}22')
    count = []
    i = 9999
    # print (all_dirctionlist)
    for direction in all_dirctionlist:
        i = i + 1
        direction=direction.replace('0','').replace('1','')
        if '22' in direction:
            count.append(i)
    return count

'''输入速度，然后输出随机时间'''

def   get_time(plantime,  speed):
    if  speed>6:
        rand_time = np.random.randint(0, 70)
        return rand_time
    elif  speed>4:
        rand_time = np.random.randint(60,  160)
        return rand_time
    elif  speed>2:
        rand_time = np.random.randint(160, 310)
        return rand_time
    elif  speed>0:
        rand_time = np.random.randint(300,480)
        return rand_time






'''本函数根据road_list 生成edges_list_name_dict
输入：road_list
输出：为edges_list_name_dict = {} 
比如：'34_42': 5063,  键为两个路口的id，值为他两个路口之间形成路的id。因为最后输出路径的时候要根据路口id 查找路径名字
'''

def  product(road_list):
    edges_list_name_dict = {}  # 两个路口间的路径名字,最后输出路径的时候要根据路口id 查找路径名字
    edges_dict={}
    point_list=[]
    matrix_dict={} 
    for road in road_list:
        edges_list_name_dict[str(road.start) + "_" + str(road.end)] = road.id
        point_list.append(road.start)
        point_list.append(road.end)
        matrix_dict[str(road.end)+"_"+str(road.start)]=road.length*road.constrain_speed*road.constrain_speed
        if road.end in edges_dict:
                edges_dict[road.end].append(road.start)
        else:
                edges_dict[road.end]=[road.start]
        if road.isDuplex == 1:
            edges_list_name_dict[str(road.end) + "_" + str(road.start)] = road.id
            matrix_dict[str(road.start)+"_"+str(road.end)]=road.length*road.constrain_speed*road.constrain_speed
            if road.start in edges_dict:
                    edges_dict[road.start].append(road.end)
            else:
                    edges_dict[road.start]=[road.end]

    return edges_list_name_dict,edges_dict,point_list,matrix_dict

# def get_same_path_max_time(carlist,edges,new_matrix_dict,edges_dict ):
#   same_path_max_time_dict={}
#   for car1 in carlist:
#       used_cross_ids, total_path_length=Dijkstra( edges,new_matrix_dict,edges_dict ,car1.start,car1.end)
#       str_res =(int(car1.id) ,int(car1.plantime))
#       for i in  range(len(used_cross_ids)-1):
#           path_name=edges_list_name_dict[str(used_cross_ids[i])+"_"+str(used_cross_ids[i+1])]
#           str_res += (int(path_name),)
#       key1=str(str_res[2])+"_"+str(str_res[-1])
#       if key1 in  same_path_max_time_dict:
#           same_path_max_time_dict[key1].append(car)
#       else:
#           same_path_max_time_dict[key1]=car
#   print(len(same_path_max_time_dict))     
#   return same_path_max_time_dict




logging.basicConfig(level=logging.DEBUG,
                    filename='../logs/CodeCraft-2019.log',
                    format='[%(asctime)s] %(levelname)s [%(funcName)s: %(filename)s, %(lineno)d] %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    filemode='a')


def main():



    if len(sys.argv) != 5:
        logging.info('please input args: car_path, road_path, cross_path, answerPath')
        exit(1)

    car_path = sys.argv[1]
    road_path = sys.argv[2]
    cross_path = sys.argv[3]
    answer_path = sys.argv[4]

    # car_path ='../config/car.txt'
    # road_path = '../config/road.txt'
    # cross_path = '../config/cross.txt'
    # answer_path ='../config/answer.txt'

    logging.info("car_path is %s" % (car_path))
    logging.info("road_path is %s" % (road_path))
    logging.info("cross_path is %s" % (cross_path))
    logging.info("answer_path is %s" % (answer_path))





    #获取edges，matrix，edges_dict.
    # edges,edges_dict= get_cross_matrix(cross_path,road_path)
    # carlist      通过文件读取来获取car_list。
    car_list=get_list(car_path,car)
    #road      通过文件读取获取road_list
    road_list = get_list(road_path,road1)
    #比如：'34_42': 5063,  键为两个路口的id，值为他两个路口之间形成路的id。
    ## 因为最后输出路径的时候要根据路口id 查找路径名字
    edges_list_name_dict,edges_dict,edges,new_matrix_dict=product(road_list)
    # new_matrix_dict = get_new_matrix_dict(road_list)

    '''
        生成最短路径list
    '''

    # answertemp=[]
    # for car1 in car_list:
    #     used_cross_ids, total_path_length=Dijkstra( edges,new_matrix_dict,edges_dict ,car1.start,car1.end)
    #     str_res =(int(car1.id) ,int(car1.plantime))
    #     for i in  range(len(used_cross_ids)-1):
    #         path_name=edges_list_name_dict[str(used_cross_ids[i])+"_"+str(used_cross_ids[i+1])]
    #         str_res += (int(path_name),)
    #     answertemp.append(str_res)

    # same_path_max_time_dict={}
    # same_plan_time_dict={}
    # path_dict={}
    # for car1 in car_list:
    #     # print("car1.id")
    #     # print(car1.id)
    #     used_cross_ids, total_path_length=Dijkstra( edges,new_matrix_dict,edges_dict ,car1.start,car1.end)
    #     str_res =(int(car1.id) ,int(car1.plantime))
    #     for i in  range(len(used_cross_ids)-1):
    #         path_name=edges_list_name_dict[str(used_cross_ids[i])+"_"+str(used_cross_ids[i+1])]
    #         str_res += (int(path_name),)
    #     key1=str(str_res[2])+"_"+str(str_res[-1])
    #     path_dict[car1.id]=str_res[2:]
    #     if key1 in  same_path_max_time_dict:
    #         same_path_max_time_dict[key1].append(car1)
    #         same_plan_time_dict[key1].append(car1.plantime)
    #     else:
    #         same_path_max_time_dict[key1]=[car1]
    #         same_plan_time_dict[key1]=[car1.plantime]
    # # print(len(same_path_max_time_dict))
    # ans_file = open(answer_path, "w")
    # ans_file.write("#(carId,StartTime,RoadId...)" + "\n")
    # j=0 
    # rand_time=0
    # for i in same_path_max_time_dict:
    #     j+=1
    #     carlist1=same_path_max_time_dict[i]
    #     max_plantime=max(same_plan_time_dict[i])
    #     if j==61:
    #         j=0
    #         rand_time +=31
    #     else:
    #         pass
    #     # print(carlist1)
    #     for car2 in carlist1:
    #         # print(car2.id)
    #         car2.plantime =max_plantime+rand_time
    #         res1=(int(car2.id) ,int(car2.plantime))+path_dict[car2.id]
    #         # print(res1)
    #         ans_file.write(str(res1)+"\n")
    # ans_file.close()
    # crosslist=get_answer(cross_path)
    # count=get_lock(answertemp,crosslist)
    # print ("输出3个右转的count")
    # print (count)
    # print ('----------------------')
    # print (len(count))


    t1=0
    t2=133#130
    t3=170
    t4=310
    index1=0
    index2=0
    index3=0
    index4=0
    time=0
    ans_file = open(answer_path, "w")
    ans_file.write("#(carId,StartTime,RoadId...)" + "\n")
    for car1 in car_list:
        # t+=1
        used_cross_ids, total_path_length=Dijkstra( edges,new_matrix_dict,edges_dict ,car1.start,car1.end)
        # if car1.id not in count:
        #     rand_time=get_time(car1.speed)
        #     car1.plantime = car1.plantime + rand_time

        # if car1.id in count:
        #     rand_time = get_time(car1.speed)
        #     car1.plantime = car1.plantime + rand_time
        # rand_time = get_time(car1.plantime,car1.speed)
        if  car1.speed>6:
            index1+=1
            if index1==300:
                index1=0
                t1 +=14
            car1.plantime +=t1
        elif car1.speed>4:
            index2+=1
            if index2==300:
                index2=0
                t2 +=12
            car1.plantime +=t2
        elif  car1.speed>2:
            index3+=1
            if index3==300:
                index3=0
                t3 +=14
            car1.plantime +=t3
        elif  car1.speed>0:
            index4+=1
            if index4==300:
                index4=0
                t4 +=14
            car1.plantime +=t4
        # car1.plantime = car1.plantime + rand_time
    #         # if int(time/1000)<1:
    #         #     rand_time = random.randint(1, 70)
    #         #     car1.plantime = car1.plantime + rand_time
    #         # elif int(time/1000)<2:
    #         #     rand_time = random.randint(7, 140)
    #         #     car1.plantime = car1.plantime + rand_time
    #         # elif int(time/1000)<3:
    #         #     rand_time = random.randint(140, 210)
    #         #     car1.plantime = car1.plantime + rand_time
    #         # elif int(time/1000)<4:
    #         #     rand_time = random.randint(210, 280)
    #         #     car1.plantime = car1.plantime + rand_time
    #         # elif int(time/1000)<5:
    #         #     rand_time = random.randint(280, 320)
    #         #     car1.plantime = car1.plantime + rand_time
    #         # elif int(time/1000)<6:
    #         #
    #         #     rand_time = random.randint(320,390)
    #         #     car1.plantime = car1.plantime + rand_time
    #         # elif int(time/1000)<7:
    #         #
    #         #     rand_time = random.randint(390, 460)
    #         #     car1.plantime = car1.plantime + rand_time
    #         # elif int(time/1000)<8:
    #         #
    #         #     rand_time = random.randint(450, 530)
    #         #     car1.plantime = car1.plantime + rand_time
    #         # elif int(time/1000)<9:
    #         #
    #         #     rand_time = random.randint(520, 590)
    #         #     car1.plantime = car1.plantime + rand_time
    #         # elif int(time/1000)<10:
    #         #     rand_time = random.randint(540, 600)
    #         #     car1.plantime = car1.plantime + rand_time
    #         # else:
    #         #     rand_time = random.randint(1,600)
    #         #     car1.plantime = car1.plantime + rand_time
        # str_res =(int(car1.id) ,int(car1.speed),int(car1.plantime))
        str_res =(int(car1.id) ,int(car1.plantime))
        for i in  range(len(used_cross_ids)-1):
            path_name=edges_list_name_dict[str(used_cross_ids[i])+"_"+str(used_cross_ids[i+1])]
            str_res += (int(path_name),)
        ans_file.write(str(str_res)+"\n")
    ans_file.close()

    



        



if __name__ == "__main__":
    main()



